/**
 * Created with JetBrains PhpStorm.
 * User: v_xiaolfang
 * Date: 12-8-6
 * Time: 下午6:55
 * To change this template use File | Settings | File Templates.
 * goal 让GridPanel的行支持拖动排序的插件
 * 插件方式支持
 * time 2011-08-05 22:04:27
 */

//<extension>
(function () {
    //先扩展一个拖放操作的放置区
    Ext.ns('Ext.ux.grid');
    Ext.ux.grid.GridDropZone = Ext.extend(Ext.dd.DropZone, {
        ddGroup: 'GridDD',
        constructor: function (grid, config) {
            this.view = grid.getView();
            Ext.ux.grid.GridDropZone.superclass.constructor.call(this, this.view.scroller.dom, config);
            this.proxyEl = document.createElement('div');
            this.proxyEl.style.cssText = "background:url(o_arrow_right.png);" +
                "width:16px;height:16px;position:absolute;";
            Ext.fly(this.proxyEl).insertAfter(this.view.scroller).hide();
        },
        getTargetFromEvent: function (e) {
            return e.getTarget(this.view.rowSelector);
        },
        onNodeEnter: function (target, dd, e, data) {
            var rowIndex = this.view.findRowIndex(target);
            data.targetRowIndex = rowIndex;
            if (rowIndex !== false) {
                rowIndex < data.rowIndex && (rowIndex += 1);
                data.targetRowIndex = rowIndex;
                if (rowIndex !== data.rowIndex) {
                    Ext.fly(this.proxyEl).show().alignTo(target, 'br-bl', [16, 9]);
                    return;
                }
            }
            Ext.fly(this.proxyEl).hide();
        },
        onNodeOut: function () {
            Ext.fly(this.proxyEl).hide();
        },
        onNodeOver: function (target, dd, e, data) {
            if (data.targetRowIndex !== false && data.targetRowIndex !== data.rowIndex) {
                return Ext.dd.DropZone.prototype.dropAllowed;
            } else {
                return Ext.dd.DropZone.prototype.dropNotAllowed;
            }
        },
        onNodeDrop: function (target, dd, e, data) {
            if (data.targetRowIndex !== data.rowIndex) {
                var record = data.grid.store.getAt(data.rowIndex);
                data.grid.store.data.removeAt(data.rowIndex);
                data.grid.store.data.insert(data.targetRowIndex, record);
                this.view.refresh();
                return true;
            }
            return false;
        },
        destroy: function () {
            Ext.destroy(this.proxyEl);
            delete this.proxyEl;
            Ext.ux.grid.GridDropZone.destroy.apply(this, arguments);
        }
    });

    //支持行拖动的插件
    //扩展自Ext.util.Observable方便以后添加事件支持
    Ext.ux.grid.RowGragable = Ext.extend(Ext.util.Observable, {
        init: function (grid) {
            grid.enableDragDrop = true;
            var group = Math.random().toString();
            grid.ddGroup = group;
            var dropZone;
            grid.on('afterrender', function () {
                dropZone = new Ext.ux.grid.GridDropZone(grid, { ddGroup: group });
            });
            grid.on('destroy', function () {
                dropZone.destroy();
            });
        }
    })
})();
//</extension>