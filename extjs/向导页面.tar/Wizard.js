/*
 * Created with JetBrains PhpStorm.
 * User: v_xiaolfang
 * Date: 12-8-6
 * Time: 下午5:34
 * To change this template use File | Settings | File Templates.
 * 配置项
 @wizards,一个WizardWrapper的数组
 @startWizardId,第一个启动的wizardwrapper
 @displayWelcome，显示欢迎面板,default true
 @displayFinish，显示结束面板,default true
 @welcomeMsg,欢迎界面的文本
 @finishMsg，结束界面的文本
 */
var Wizard = Ext.extend(Ext.util.Observable, {
    startWizardId: 'welcome',
    displayWelcome: true,
    displayFinish: true,
    welcomeMsg: '<h1>欢迎使用向导功能！</h1>',
    finishMsg: '<h1>向导结束，谢谢使用！</h1>',
    wizards: [],
    constructor: function (config) {
        config = config || {};
        config.wizard && !Ext.isArray(config.wizard) && (config.wizard = [config.wizard]);
        Ext.apply(this, config);
        Wizard.superclass.constructor.call(this, config);
        this.addEvents(
            'beforechangeww', /*改变向导面板前*/
            'changeww', /*改变面板后*/
            'cancel', /*当取消向导时*/
            'complete', /*当完成向导时*/
            'finish'/*当结束向导时*/
        );
        this.initWizard();
        this.initEvents();
        this.stream = []; //记录了向导的过程
    },
    startUp: function () {
        this.getWWWindow().show();
        this.stream.push(this.startWizardId);
        this.displayWW(this.startWizardId);
    },
    endUp: function () {
        this.destroy();
    },
    getWW: function (wwId) {
        return this.wizards[wwId];
    },
    //private
    displayWW: function (wwId) {
        var tempWW = this.wizards[wwId];
        tempWW && this.getWWWindow().displayWW(tempWW);
    },
    //private
    initWizard: function () {
        this.processWizard();

        var temp = {};
        Ext.each(this.wizards, function (ww) {
            temp[ww.id] = Ext.create(ww, 'wizardwrapper');
        });
        this.wizards = temp;
    },
    //private
    processWizard: function () {
        if (this.displayWelcome) {
            var welcomeWW = {
                id: 'welcome', enableButtons: '0110',
                panel: { html: this.welcomeMsg, border: false }
            };
            var choices = [this.startWizardId, 'finish'];
            welcomeWW.nextWWId = choices[Number(this.startWizardId === 'welcome')];
            this.startWizardId = 'welcome';
            this.wizards = [welcomeWW].concat(this.wizards);
        }
        if (this.displayFinish) {
            var finishWW = {
                id: 'finish', enableButtons: '0001',
                panel: { html: this.finishMsg, border: false }
            }
            Ext.each(this.wizards, function (ww) {
                ww.nextWWId === undefined && (ww.nextWWId = 'finish');
            });
            this.wizards.push(finishWW);
        }
    },
    destroy: function () {
        Ext.iterate(this.wizards, function (wwId, ww) {
            ww && ww.destroy();
        }, this);
        this.purgeListeners();
        delete this.wizards;
        this.wwWindow && this.wwWindow.destroy();
    },
    //private
    getWWWindow: function () {
        this.wwWindow = this.wwWindow || new WizardWindow();
        return this.wwWindow;
    },
    //private
    initEvents: function () {
        Ext.iterate(this.wizards, function (wwId, ww) {
            ww.on('goprev', this.onGoPrev, this);
            ww.on('gonext', this.onGoNext, this);
            ww.on('cancel', this.onCancel, this);
            ww.on('complete', this.onCompelete, this);
        }, this);
        this.on('finish', this.onFinish, this);
    },
    //private
    onGoPrev: function (ww, wwId) {
        if (this.fireEvent('beforechangeww', this, ww, wwId, 'prev') !== false) {
            ww.hide();
            this.stream.pop();
            this.displayWW(wwId);
            this.fireEvent('changeww', this, ww, wwId, 'prev');
        }
    },
    //private
    onGoNext: function (ww, wwId) {
        if (this.fireEvent('beforechangeww', this, ww, wwId, 'next') !== false) {
            ww.hide();
            this.stream.push(wwId);
            this.displayWW(wwId);
            this.wizards[wwId] && this.wizards[wwId].setPrevWW(ww.id);
            this.fireEvent('changeww', this, ww, wwId, 'next');
        }
    },
    //private
    onCancel: function (ww) {
        if (this.fireEvent('cancel', this, ww) !== false) {
            this.fireEvent('finish', this, ww, 'cancel');
        }
    },
    //private
    onCompelete: function (ww) {
        if (this.fireEvent('complete', this, ww) !== false) {
            this.fireEvent('finish', this, ww, 'complete');
        }
    },
    //private
    onFinish: function (wizard, ww) {
        this.endUp();
    },
    //返回向导的过程
    getStream: function () {
        var temp = {};
        Ext.each(this.stream, function (s) {
            temp[s] = this.wizards[s];
        }, this);
        return temp;
    }
});

var WizardWindow = Ext.extend(Ext.Window, {
    initComponent: function () {
        Ext.apply(this, {
            layout: 'anchor', modal: true, closable: false, border: false,
            items: [
                { xtype: 'panel', anchor: '100% 100%', bodyStyle: 'border-color:transparent', layout: 'anchor' }
            ]
        });
        WizardWindow.superclass.initComponent.call(this);
    },
    displayWW: function (ww) {
        this.setSize(ww.winWidth, ww.winHeight);
        this.setTitle(ww.winTitle);
        var wwCt = this.items.get(0);
        ww.show();
        wwCt.add(ww);
        this.center();
        this.doLayout();
    }
});