/*
 * Created with JetBrains PhpStorm.
 * User: v_xiaolfang
 * Date: 12-8-6
 * Time: 下午5:35
 * To change this template use File | Settings | File Templates.
 wizard包装器
 配置项
 @enablePrev，是否允许上一步，default true
 @enableNext，是否允许下一步，default true
 @enableCancel，是否允许取消, default true
 @enableComplete，是否允许完成向导，default false
 @enableButtons，或许这个来配置按钮的有效性更方便。用4位来配置这4个按钮
 @prevButtonText，上一步的按钮文字
 @nextButtonText，下一步的按钮文字
 @cancelButtonText，取消按钮的文字
 @completeButtonText，完成按钮的文字
 @id，表示这个wizard
 @panel，被包装的panel
 @destroyPanel,在关闭向导时是否将panel销毁，default true
 @nextWWId 该wizardwrapper的下一个面板的id
 */
var WizardWrapper = Ext.extend(Ext.Panel, {
    enablePrev: true,
    enableNext: true,
    enableCancel: true,
    enableComplete: false,
    enableButtons:'1110',
    prevButtonText: '上一步',
    nextButtonText: '下一步',
    cancelButtonText: '取消',
    completeButtonText: '完成',
    destroyPanel: true,
    nextWWId: undefined, /*下一个wizardwrapper的id，复杂的跳转需要实现getNextWW*/
    winWidth: 500,
    winHeight: 300,
    winTitle: '向导',
    constructor: function (config) {
        config = config || {};
        if (config.id === undefined) {
            throw 'you must configure the id'
        }
        WizardWrapper.superclass.constructor.call(this, config);
    },
    //private
    initComponent: function () {
        this.initButtons();

        this.title && (this.winTitle = this.title);
        this.width && (this.winWidth = this.width);
        this.height && (this.winHeight = this.height);
        delete this.title;
        delete this.width;
        delete this.height;

        this._panel = Ext.create(this.panel, 'panel');
        delete this.panel;
        Ext.apply(this, {
            border: true, frame: true,
            anchor: '100% 100%',
            buttons: this.getButtons(),
            items: [
                this._panel
            ]
        });
        WizardWrapper.superclass.initComponent.call(this);
        this.addEvents(
            'beforegoprev', /*当点击上一步时,this,preWW*/
            'goprev', /*当点击上一步时,this,preWW*/
            'beforegonext', /*当点击下一步时,this,nextWW*/
            'gonext', /*当点击下一步时,this,nextWW*/
            'beforecancel', /*在取消事件发生之前,this*/
            'cancel', /*当点击取消时,this*/
            'beforecomplete', /*在完成事件发生之前,this*/
            'complete'/*当点击完成时,this*/
        )
    },
    //private
    initButtons: function () {
        if (this.enableButtons) {
            var ebs = parseInt(this.enableButtons, 2);
            this.enablePrev = ((8 & ebs) === 8);
            this.enableNext = ((4 & ebs) === 4);
            this.enableCancel = ((2 & ebs) === 2);
            this.enableComplete = ((1 & ebs) === 1);
        }
    },
    //private
    getButtons: function () {
        var buttons = [];
        this.enablePrev && buttons.push({ xtype: 'tbbutton', text: this.prevButtonText, handler: this.onPrevClick.createDelegate(this) });
        this.enableNext && buttons.push({ xtype: 'tbbutton', text: this.nextButtonText, handler: this.onNextClick.createDelegate(this) });
        this.enableCancel && buttons.push({ xtype: 'tbbutton', text: this.cancelButtonText, handler: this.onCancelClick.createDelegate(this) });
        this.enableComplete && buttons.push({ xtype: 'tbbutton', text: this.completeButtonText, handler: this.onCompleteClick.createDelegate(this) });
        return buttons;
    },
    getProxy: function () {
        return this._panel;
    },
    //private
    onPrevClick: function () {
        if (this.fireEvent('beforegoprev', this, this._prevWWId) !== false) {
            this.fireEvent('goprev', this, this._prevWWId);
        }
    },
    //private
    onNextClick: function () {
        if (this.fireEvent('beforegonext', this, this.getNextWW()) !== false) {
            this.fireEvent('gonext', this, this.getNextWW());
        }
    },
    //private
    onCancelClick: function () {
        if (this.fireEvent('beforecancel', this)!==false) {
            this.fireEvent('cancel', this);
        }
    },
    //private
    onCompleteClick: function () {
        if (this.fireEvent('beforecomplete', this) !== false) {
            this.fireEvent('complete', this);
        }
    },
    destroy: function () {
        if (this.destroyPanel) {
            this._panel && this._panel.destroy();
        }
        delete this._panel;
        WizardWrapper.superclass.destroy.call(this);
    },
    setPrevWW: function (wwId) {
        this._prevWWId = wwId;
    },
    //如果向导跳转复杂，则需要实现这个方法
    getNextWW: function () {
        return this.nextWWId;
    }
});
Ext.reg('wizardwrapper', WizardWrapper);